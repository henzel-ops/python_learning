# calculations using math module

import math

num = float(input("Enter a number: "))
print(f"Square root: {math.sqrt(num)}")
print(f"Logarithm: {math.log(num)}")
print(f"Sine: {math.sin(num)}")