result = 0
for num in range(1, 51):
    result += num
print(f"The sum of integers from 1 to 50 is: {result}")