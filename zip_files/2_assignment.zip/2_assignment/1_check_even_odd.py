num = int(input("Enter a number: "))
print(f"{num} is even number") if num % 2 == 0 else print(f"{num} is odd number")